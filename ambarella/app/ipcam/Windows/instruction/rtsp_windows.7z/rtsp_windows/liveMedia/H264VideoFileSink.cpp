/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// "liveMedia"
// Copyright (c) 1996-2010 Live Networks, Inc.  All rights reserved.
// H.264 Video File sinks
// Implementation

#include "H264VideoFileSink.hh"
#include "OutputFile.hh"
#include <Mmsystem.h>
#include <Windows.h>
////////// H264VideoFileSink //////////

H264VideoFileSink
::H264VideoFileSink(UsageEnvironment& env, FILE* fid, unsigned bufferSize,
			 char const* perFrameFileNamePrefix, Boolean saveflag, unsigned int gop, unsigned statwindowSize)
	: FileSink(env, fid, bufferSize, perFrameFileNamePrefix),
	fSaveFlag(saveflag),
	fgop(gop),
	ftotalCnt(0),
	flossCnt(0),
	//flastIDR(0)
	flastFrameNum(fgop-1),
	fstatSize(statwindowSize),
	fAveragepts(0){
	timeBeginPeriod(1);
	statBegin = new DWORD[statwindowSize];
}

H264VideoFileSink::~H264VideoFileSink() {
	printStat();
	timeEndPeriod(1);
	delete[] statBegin;
}

H264VideoFileSink*
H264VideoFileSink::createNew(UsageEnvironment& env, char const* fileName,
				  unsigned bufferSize, Boolean oneFilePerFrame,Boolean saveFlag, unsigned int gop,unsigned statwindowSize) {
  do {
	  FILE* fid;
	  char const* perFrameFileNamePrefix;
	  if (oneFilePerFrame) {
			// Create the fid for each frame
		  fid = NULL;
		  perFrameFileNamePrefix = fileName;
		} else if (saveFlag){
			// Normal case: create the fid once
		  fid = OpenOutputFile(env, fileName);
		  if (fid == NULL) break;
		  perFrameFileNamePrefix = NULL;
		}

	  return new H264VideoFileSink(env, fid, bufferSize, perFrameFileNamePrefix,saveFlag,gop,statwindowSize);
	} while (0);

  return NULL;
}

Boolean H264VideoFileSink::sourceIsCompatibleWithUs(MediaSource& source) {
	// Just return true, should be checking for H.264 video streams though
	  return True;
}

void H264VideoFileSink::afterGettingFrame1(unsigned frameSize,
					  struct timeval presentationTime) {
	short  nal_unit_type = fBuffer[0] & 0x1F;
/*  if (nal_unit_type == 5 ) {
	
	ftotalCnt++;
	if (flastIDR != 0 ) {
		flossCnt = fgop - (ftotalCnt - flastIDR);
	} 
	flastIDR = ftotalCnt;

  } else if (nal_unit_type == 1) {
	ftotalCnt++;
  }*/
  	
	if (nal_unit_type == 5 || nal_unit_type == 1) {	

		statEnd = timeGetTime();
		unsigned int frame_num=0;
		u_int8_t bit_pos = 0;
		unsigned char *slice_header = fBuffer+1;
		int first_mb_in_slice,slice_type,pic_parameter_set_id;
		slice_header += parse_exp_codes(slice_header ,&first_mb_in_slice, &bit_pos,0);
		slice_header += parse_exp_codes(slice_header ,&slice_type, &bit_pos,0);
		slice_header += parse_exp_codes(slice_header ,&pic_parameter_set_id, &bit_pos,0);
		slice_header += read_bit(slice_header, (int *)(&frame_num), &bit_pos, 9);
		if (ftotalCnt == 0) {
			statBegin[0]= statEnd;	
		} else  {
			flossCnt += (frame_num <= flastFrameNum) ? 
				(frame_num + fgop - flastFrameNum -1) : (frame_num - flastFrameNum -1);
		}
		if (ftotalCnt == 300 ) {
			statBegin[0]= statEnd;	
		} else if (ftotalCnt >300 ) {
			if ((ftotalCnt - 300) <= fstatSize) {
				fAveragepts = 1000.0f*(ftotalCnt - 300) /(statEnd -statBegin[0]);
			} else {
				fAveragepts = 1000.0f*fstatSize /(statEnd -statBegin[(ftotalCnt - 300)%fstatSize]);
			}
			statBegin[(ftotalCnt - 300)%fstatSize] = statEnd;
		}
		
		ftotalCnt++;
		flastFrameNum = frame_num;
	}
	
	
  if (fSaveFlag) {
  	unsigned char start_code[4] = {0x00, 0x00, 0x00, 0x01};
  	addData(start_code, 4, presentationTime);

	// Call the parent class to complete the normal file write with the input data:
  	FileSink::afterGettingFrame1(frameSize, presentationTime);
  } else {
	FileSink::continuePlaying();
  }
  	
}

void H264VideoFileSink::printStat() {
	printf("received %u frames in total, framerate = %.3f fps, lost %u frames\nloss percentage is %.2f%%\n",
		ftotalCnt, fAveragepts, flossCnt, 100.0f*flossCnt/(flossCnt+ftotalCnt));
}


int H264VideoFileSink::read_bit(unsigned char* pBuffer,  int* value, u_int8_t* bit_pos, int num )
{
	if (num <0)
	{
		return -1;
	}
	*value = 0;
	int i=0;
	for (int j =0 ; j<num; j++)
	{
		if (*bit_pos == 8)
		{
			*bit_pos = 0;
			i++;
		}
		*value  <<= 1;
		*value  += pBuffer[i] >> (7 -(*bit_pos)++) & 0x1;
	}
	return i;
};

int H264VideoFileSink:: parse_exp_codes(unsigned char* pBuffer, int* value,  u_int8_t* bit_pos,u_int8_t type)
{
	int leadingZeroBits = -1;
	int i=0;
	u_int8_t j=*bit_pos;
	for (u_int8_t b = 0; !b; leadingZeroBits++,j++)
	{
		if(j == 8)
		{
			i++;
			j=0;
		}
		b = pBuffer[i] >> (7 -j) & 0x1;
	}
	int codeNum = 0;
		i += read_bit(pBuffer+i,  &codeNum, &j, leadingZeroBits);
		codeNum += (1 << leadingZeroBits) -1;
		if (type == 0) //ue(v)
		{
			*value = codeNum;
		}
		else if (type == 1) //se(v)
		{
			*value = (codeNum/2+1);
			if (codeNum %2 == 0)
			{
				*value *= -1;
			}
		}
		*bit_pos = j;
		return i;
	}

