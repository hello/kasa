void TRACE(const char *fmt, ...)
{
	 char out[1024];
	 va_list body;
	 va_start(body, fmt);
	 StringCchVPrintf(out, sizeof(out), fmt, body);
	 va_end(body);
	 OutputDebugString(out);
}
